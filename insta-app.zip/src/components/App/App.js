import React from 'react'
import HomePage from '../../pages/HomePage'

const App = () => (
  <div className='App'>
    <HomePage />
  </div>
)

export default App
